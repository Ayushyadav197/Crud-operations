package com.wrestling.WRESTLING;

import javax.websocket.server.PathParam;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WrestlingController {

	@Autowired
	SessionFactory sessionFactory;

	@PostMapping("addplayer")
	public Wrestling addplayers(@RequestBody Wrestling wrestling) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(wrestling);
		transaction.commit();
		return wrestling;
	}

	@GetMapping("player/{id}")
	public Wrestling fetchdataofplayer(@PathVariable Integer id) {
		Session session = sessionFactory.openSession();
		Wrestling wrestling = session.get(Wrestling.class, id);
		return wrestling;
	}

	@DeleteMapping("hi1/{id}")
	public void deletedata(@PathVariable Integer id) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Wrestling wrestling = session.load(Wrestling.class, id);
		session.delete(wrestling);
		transaction.commit();

	
	
	
	}
	@PutMapping("updatebyname")
	public void addiupdate(@RequestBody Wrestling w){
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
   Query query= session.createQuery("update Wrestling set year=:year,medal=:medal where pname=:pname");
   query.setParameter(1, w.year);
   query.setParameter(2, w.medal);
   query.setParameter(3, w.pname);
   query.executeUpdate();
    transaction.commit();
	}

	@PutMapping("hi8")
	public String updatedata(@RequestBody Wrestling w) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		// Wrestling wrestling= session.load(Wrestling.class, w.id);
		 Wrestling load = session.load(Wrestling.class, w.id);
		session.saveOrUpdate(w);
		transaction.commit();
		return "data updated successfully";
	}

	@DeleteMapping("hi2/{id}")
	public Wrestling deletedatawithid(@PathVariable Integer id) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Wrestling wrestling = session.load(Wrestling.class, id);
		session.delete(wrestling);
		transaction.commit();
		return wrestling;
	}

	// @DeleteMapping("hi21/{pname}")
	// public Wrestling deletedatawithname(@PathVariable String pname){
	// Session session=sessionFactory.openSession();
	// Transaction transaction=session.beginTransaction();
	// Wrestling wrestling=session.load(Wrestling.class, pname);
	// session.delete(wrestling);
	// transaction.commit();
	// return wrestling;
	// }

	@RequestMapping("hii")
	public String addingdata() {
		System.out.println("hello");
		return "hello ayush yadav is here ";
	}

}