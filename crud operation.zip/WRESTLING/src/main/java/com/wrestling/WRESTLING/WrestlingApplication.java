package com.wrestling.WRESTLING;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WrestlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WrestlingApplication.class, args);
		System.out.println("Wrestling");
		System.out.println("hello this is free style wrestling");
//		int x=127;
//		x++;
//		x++;
//		System.out.println(x);
		
	}

}
