package com.wrestling.WRESTLING;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Wrestling {
	@Id
	int id;
	int weightcat;

	String pname;
	String country;
	int year;
	String medal;

	public Wrestling() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Wrestling(int id, int weightcat, String pname, String country, int year, String medal) {
		super();
		this.id = id;
		this.weightcat = weightcat;
		this.pname = pname;
		this.country = country;
		this.year = year;
		this.medal = medal;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getWeightcat() {
		return weightcat;
	}

	public void setWeightcat(int weightcat) {
		this.weightcat = weightcat;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getMedal() {
		return medal;
	}

	public void setMedal(String medal) {
		this.medal = medal;
	}

	@Override
	public String toString() {
		return "Wrestling [id=" + id + ", weightcat=" + weightcat + ", pname=" + pname + ", country=" + country
				+ ", year=" + year + ", medal=" + medal + "]";
	}

}
